class Book {
    constructor(ISBN, title, year, category, subject, language, pages) {
        this.ISBN = ISBN;
        this.title = title;
        this.year = year;
        this.category = category;
        this.subject = subject;
        this.language = language;
        this.pages = pages;
    }
}



class Author {
    constructor(AuthorID, firstname, lastname, age, email, country, publications) {
        this.AuthorID = AuthorID;
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
        this.email = email;
        this.country = country;
        this.publications = publications;
    }
}


class LibraryBranch {
    constructor(BranchID, BranchName, City, ZipCode) {
        this.BranchID = BranchID;
        this.BranchName = BranchName;
        this.City = City;
        this.ZipCode = ZipCode;
    }
}



class Genre {
    constructor(GenreID, GenreName, SubGenre) {
        this.GenreID = GenreID;
        this.GenreName = GenreName;
        this.SubGenre = SubGenre;

    }
}

class PublicationCompany {
    constructor(PublisherID, PublisherName, PublisherCountry) {
        this.PublisherID = PublisherID;
        this.PublisherName = PublisherName;
        this.PublisherCountry = PublisherCountry;

    }
}

const Book1 = new Book(205215986, 'Ultimate Javascript for Beginners', 1997, 'Computer Science', 'Web Development', 154);
const Author1 = new Author(455, 'John', 'Smith', 61, 'john.smith@email.com', 'Canada', 3);
const LibraryBranch1 = new LibraryBranch(3, 'Victory Public Library', 'Montreal', 256312);
const Genre1 = new Genre(9856617, 'Fiction', 'Thriller');
const PublicationCompany1 = new PublicationCompany(2450778919, 'Oreilly', 'USA');



document.getElementById('ShowBooks').innerHTML = Book1.ISBN + ", '<i>" + Book1.title + "</i>', " + Book1.year + ", " + Book1.category + ", " + Book1.subject + ", " + Book1.language;
document.getElementById('ShowAuthors').innerHTML = Author1.AuthorID + ", <b>" + Author1.firstname + " " + Author1.lastname + "</b>, " + Author1.age + ", <u>" + Author1.email + "</u>, " + Author1.country + ", " + Author1.publications;
document.getElementById('ShowLibraryBranches').innerHTML = LibraryBranch1.BranchID + ", <b>" + LibraryBranch1.BranchName + "</b>, " + LibraryBranch1.City + ", " + LibraryBranch1.ZipCode;
document.getElementById('ShowGenres').innerHTML = Genre1.GenreID + ", " + Genre1.GenreName + ", " + Genre1.SubGenre;
document.getElementById('ShowPublishers').innerHTML = PublicationCompany1.PublisherID + ", " + PublicationCompany1.PublisherName + ", " + PublicationCompany1.PublisherCountry;